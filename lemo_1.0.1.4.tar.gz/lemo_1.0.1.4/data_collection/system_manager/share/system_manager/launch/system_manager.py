from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.substitutions import FindPackageShare
import os

user_home = os.getenv("HOME")
sysmgr_log_dir = os.path.join(user_home, 'galaxea/log/')
launch_ws_ip = os.getenv("SYSMGR_AGNET_IP")
if launch_ws_ip is None:
    launch_ws_ip = '0.0.0.0'

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('log_out_dir', default_value=sysmgr_log_dir),
        DeclareLaunchArgument('system_manager_task_navigation_action_name', default_value='/system_manager/navi/action'),
        DeclareLaunchArgument('system_manager_task_manipulation_action_name', default_value='/system_manager/manipulation/action'),
        DeclareLaunchArgument('system_manager_task_teleop_engage_topic_name', default_value='/system_manager/task/teleop_engage'),
        DeclareLaunchArgument('launch_ws_ip', default_value=launch_ws_ip),
        DeclareLaunchArgument('cancel_model_act_wait_time_ms', default_value="'1'"),
        DeclareLaunchArgument('head_cam_stream_topic', default_value='/hdas/camera_head/left_raw/image_raw_color/compressed'),
        DeclareLaunchArgument('left_wrist_cam_stream_topic', default_value='/hdas/camera_wrist_left/color/image_raw/compressed'),
        DeclareLaunchArgument('right_wrist_cam_stream_topic', default_value='/hdas/camera_wrist_right/color/image_raw/compressed'),
        DeclareLaunchArgument('head_cam_stream_port', default_value="'52134'"),
        DeclareLaunchArgument('left_wrist_cam_stream_port', default_value="'52135'"),
        DeclareLaunchArgument('right_wrist_cam_stream_port', default_value="'52136'"),

        Node(
            package='system_manager',
            executable='system_manager',
            name='system_manager',
            output='screen',
            parameters=[{
                'log_out_dir': LaunchConfiguration('log_out_dir'),
                'system_manager_task_navigation_action_name': LaunchConfiguration('system_manager_task_navigation_action_name'),
                'system_manager_task_manipulation_action_name': LaunchConfiguration('system_manager_task_manipulation_action_name'),
                'system_manager_task_teleop_engage_topic_name': LaunchConfiguration('system_manager_task_teleop_engage_topic_name'),
                'launch_ws_ip': LaunchConfiguration('launch_ws_ip'),
                'cancel_model_act_wait_time_ms': LaunchConfiguration('cancel_model_act_wait_time_ms'),
                'head_cam_stream_topic': LaunchConfiguration('head_cam_stream_topic'),
                'left_wrist_cam_stream_topic': LaunchConfiguration('left_wrist_cam_stream_topic'),
                'right_wrist_cam_stream_topic': LaunchConfiguration('right_wrist_cam_stream_topic'),
                'head_cam_stream_port': LaunchConfiguration('head_cam_stream_port'),
                'left_wrist_cam_stream_port': LaunchConfiguration('left_wrist_cam_stream_port'),
                'right_wrist_cam_stream_port': LaunchConfiguration('right_wrist_cam_stream_port'),
            }]
        ),
    ])
