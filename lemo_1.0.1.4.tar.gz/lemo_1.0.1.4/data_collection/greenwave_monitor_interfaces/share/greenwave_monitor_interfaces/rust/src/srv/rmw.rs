#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



#[link(name = "greenwave_monitor_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__greenwave_monitor_interfaces__srv__ManageTopic_Request() -> *const std::ffi::c_void;
}

#[link(name = "greenwave_monitor_interfaces__rosidl_generator_c")]
extern "C" {
    fn greenwave_monitor_interfaces__srv__ManageTopic_Request__init(msg: *mut ManageTopic_Request) -> bool;
    fn greenwave_monitor_interfaces__srv__ManageTopic_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ManageTopic_Request>, size: usize) -> bool;
    fn greenwave_monitor_interfaces__srv__ManageTopic_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ManageTopic_Request>);
    fn greenwave_monitor_interfaces__srv__ManageTopic_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ManageTopic_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<ManageTopic_Request>) -> bool;
}

// Corresponds to greenwave_monitor_interfaces__srv__ManageTopic_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ManageTopic_Request {
    /// Request
    pub topic_name: rosidl_runtime_rs::String,

    /// true to add, false to remove
    pub add_topic: bool,

}



impl Default for ManageTopic_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !greenwave_monitor_interfaces__srv__ManageTopic_Request__init(&mut msg as *mut _) {
        panic!("Call to greenwave_monitor_interfaces__srv__ManageTopic_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ManageTopic_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { greenwave_monitor_interfaces__srv__ManageTopic_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { greenwave_monitor_interfaces__srv__ManageTopic_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { greenwave_monitor_interfaces__srv__ManageTopic_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ManageTopic_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ManageTopic_Request where Self: Sized {
  const TYPE_NAME: &'static str = "greenwave_monitor_interfaces/srv/ManageTopic_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__greenwave_monitor_interfaces__srv__ManageTopic_Request() }
  }
}


#[link(name = "greenwave_monitor_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__greenwave_monitor_interfaces__srv__ManageTopic_Response() -> *const std::ffi::c_void;
}

#[link(name = "greenwave_monitor_interfaces__rosidl_generator_c")]
extern "C" {
    fn greenwave_monitor_interfaces__srv__ManageTopic_Response__init(msg: *mut ManageTopic_Response) -> bool;
    fn greenwave_monitor_interfaces__srv__ManageTopic_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ManageTopic_Response>, size: usize) -> bool;
    fn greenwave_monitor_interfaces__srv__ManageTopic_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ManageTopic_Response>);
    fn greenwave_monitor_interfaces__srv__ManageTopic_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ManageTopic_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<ManageTopic_Response>) -> bool;
}

// Corresponds to greenwave_monitor_interfaces__srv__ManageTopic_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ManageTopic_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for ManageTopic_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !greenwave_monitor_interfaces__srv__ManageTopic_Response__init(&mut msg as *mut _) {
        panic!("Call to greenwave_monitor_interfaces__srv__ManageTopic_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ManageTopic_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { greenwave_monitor_interfaces__srv__ManageTopic_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { greenwave_monitor_interfaces__srv__ManageTopic_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { greenwave_monitor_interfaces__srv__ManageTopic_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ManageTopic_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ManageTopic_Response where Self: Sized {
  const TYPE_NAME: &'static str = "greenwave_monitor_interfaces/srv/ManageTopic_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__greenwave_monitor_interfaces__srv__ManageTopic_Response() }
  }
}


#[link(name = "greenwave_monitor_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request() -> *const std::ffi::c_void;
}

#[link(name = "greenwave_monitor_interfaces__rosidl_generator_c")]
extern "C" {
    fn greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request__init(msg: *mut SetExpectedFrequency_Request) -> bool;
    fn greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SetExpectedFrequency_Request>, size: usize) -> bool;
    fn greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SetExpectedFrequency_Request>);
    fn greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SetExpectedFrequency_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<SetExpectedFrequency_Request>) -> bool;
}

// Corresponds to greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SetExpectedFrequency_Request {
    /// Request
    pub topic_name: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub expected_hz: f64,

    /// i.e. 5 = 5% of expected_hz
    pub tolerance_percent: f64,


    // This member is not documented.
    #[allow(missing_docs)]
    pub clear_expected: bool,

    /// add topic to monitoring if not already
    pub add_topic_if_missing: bool,

}



impl Default for SetExpectedFrequency_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request__init(&mut msg as *mut _) {
        panic!("Call to greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SetExpectedFrequency_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SetExpectedFrequency_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SetExpectedFrequency_Request where Self: Sized {
  const TYPE_NAME: &'static str = "greenwave_monitor_interfaces/srv/SetExpectedFrequency_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__greenwave_monitor_interfaces__srv__SetExpectedFrequency_Request() }
  }
}


#[link(name = "greenwave_monitor_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response() -> *const std::ffi::c_void;
}

#[link(name = "greenwave_monitor_interfaces__rosidl_generator_c")]
extern "C" {
    fn greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response__init(msg: *mut SetExpectedFrequency_Response) -> bool;
    fn greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SetExpectedFrequency_Response>, size: usize) -> bool;
    fn greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SetExpectedFrequency_Response>);
    fn greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SetExpectedFrequency_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<SetExpectedFrequency_Response>) -> bool;
}

// Corresponds to greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SetExpectedFrequency_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for SetExpectedFrequency_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response__init(&mut msg as *mut _) {
        panic!("Call to greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SetExpectedFrequency_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SetExpectedFrequency_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SetExpectedFrequency_Response where Self: Sized {
  const TYPE_NAME: &'static str = "greenwave_monitor_interfaces/srv/SetExpectedFrequency_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__greenwave_monitor_interfaces__srv__SetExpectedFrequency_Response() }
  }
}






#[link(name = "greenwave_monitor_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__greenwave_monitor_interfaces__srv__ManageTopic() -> *const std::ffi::c_void;
}

// Corresponds to greenwave_monitor_interfaces__srv__ManageTopic
#[allow(missing_docs, non_camel_case_types)]
pub struct ManageTopic;

impl rosidl_runtime_rs::Service for ManageTopic {
    type Request = ManageTopic_Request;
    type Response = ManageTopic_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__greenwave_monitor_interfaces__srv__ManageTopic() }
    }
}




#[link(name = "greenwave_monitor_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__greenwave_monitor_interfaces__srv__SetExpectedFrequency() -> *const std::ffi::c_void;
}

// Corresponds to greenwave_monitor_interfaces__srv__SetExpectedFrequency
#[allow(missing_docs, non_camel_case_types)]
pub struct SetExpectedFrequency;

impl rosidl_runtime_rs::Service for SetExpectedFrequency {
    type Request = SetExpectedFrequency_Request;
    type Response = SetExpectedFrequency_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__greenwave_monitor_interfaces__srv__SetExpectedFrequency() }
    }
}


