# generated from rosidl_generator_py/resource/_idl.py.em
# with input from perception_msg:msg/LaneSegmentPerception.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_LaneSegmentPerception(type):
    """Metaclass of message 'LaneSegmentPerception'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('perception_msg')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'perception_msg.msg.LaneSegmentPerception')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__lane_segment_perception
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__lane_segment_perception
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__lane_segment_perception
            cls._TYPE_SUPPORT = module.type_support_msg__msg__lane_segment_perception
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__lane_segment_perception

            from perception_msg.msg import LaneSegment
            if LaneSegment.__class__._TYPE_SUPPORT is None:
                LaneSegment.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class LaneSegmentPerception(metaclass=Metaclass_LaneSegmentPerception):
    """Message class 'LaneSegmentPerception'."""

    __slots__ = [
        '_available',
        '_lane_segments',
        '_reserved_infos',
    ]

    _fields_and_field_types = {
        'available': 'uint64',
        'lane_segments': 'sequence<perception_msg/LaneSegment>',
        'reserved_infos': 'sequence<string>',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint64'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.NamespacedType(['perception_msg', 'msg'], 'LaneSegment')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.UnboundedString()),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.available = kwargs.get('available', int())
        self.lane_segments = kwargs.get('lane_segments', [])
        self.reserved_infos = kwargs.get('reserved_infos', [])

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.available != other.available:
            return False
        if self.lane_segments != other.lane_segments:
            return False
        if self.reserved_infos != other.reserved_infos:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def available(self):
        """Message field 'available'."""
        return self._available

    @available.setter
    def available(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'available' field must be of type 'int'"
            assert value >= 0 and value < 18446744073709551616, \
                "The 'available' field must be an unsigned integer in [0, 18446744073709551615]"
        self._available = value

    @builtins.property
    def lane_segments(self):
        """Message field 'lane_segments'."""
        return self._lane_segments

    @lane_segments.setter
    def lane_segments(self, value):
        if __debug__:
            from perception_msg.msg import LaneSegment
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, LaneSegment) for v in value) and
                 True), \
                "The 'lane_segments' field must be a set or sequence and each value of type 'LaneSegment'"
        self._lane_segments = value

    @builtins.property
    def reserved_infos(self):
        """Message field 'reserved_infos'."""
        return self._reserved_infos

    @reserved_infos.setter
    def reserved_infos(self, value):
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, str) for v in value) and
                 True), \
                "The 'reserved_infos' field must be a set or sequence and each value of type 'str'"
        self._reserved_infos = value
