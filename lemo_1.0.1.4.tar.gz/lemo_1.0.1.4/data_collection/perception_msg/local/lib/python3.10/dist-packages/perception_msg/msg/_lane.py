# generated from rosidl_generator_py/resource/_idl.py.em
# with input from perception_msg:msg/Lane.idl
# generated code does not contain a copyright notice


# Import statements for member types

# Member 'points_2d_x'
# Member 'points_2d_y'
# Member 'points_2d_v'
# Member 'coefficient_bv'
# Member 'coefficient_bv_sigma'
# Member 'points_3d_x'
# Member 'points_3d_y'
# Member 'points_3d_z'
import array  # noqa: E402, I100

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_Lane(type):
    """Metaclass of message 'Lane'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('perception_msg')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'perception_msg.msg.Lane')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__lane
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__lane
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__lane
            cls._TYPE_SUPPORT = module.type_support_msg__msg__lane
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__lane

            from perception_msg.msg import CameraModelEnum
            if CameraModelEnum.__class__._TYPE_SUPPORT is None:
                CameraModelEnum.__class__.__import_type_support__()

            from perception_msg.msg import CameraSourceEnum
            if CameraSourceEnum.__class__._TYPE_SUPPORT is None:
                CameraSourceEnum.__class__.__import_type_support__()

            from perception_msg.msg import LaneColorEnum
            if LaneColorEnum.__class__._TYPE_SUPPORT is None:
                LaneColorEnum.__class__.__import_type_support__()

            from perception_msg.msg import LaneHorizontalTypeEnum
            if LaneHorizontalTypeEnum.__class__._TYPE_SUPPORT is None:
                LaneHorizontalTypeEnum.__class__.__import_type_support__()

            from perception_msg.msg import LaneTypeEnum
            if LaneTypeEnum.__class__._TYPE_SUPPORT is None:
                LaneTypeEnum.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class Lane(metaclass=Metaclass_Lane):
    """Message class 'Lane'."""

    __slots__ = [
        '_camera_source',
        '_camera_model',
        '_score',
        '_index',
        '_points_2d_x',
        '_points_2d_y',
        '_points_2d_v',
        '_track_id',
        '_coefficient_bv',
        '_coefficient_bv_sigma',
        '_is_failed_3d',
        '_lane_type',
        '_lane_color',
        '_lane_width',
        '_is_centerline',
        '_points_3d_x',
        '_points_3d_y',
        '_points_3d_z',
        '_is_horizontal_line',
        '_lane_horizontal_type',
        '_stopline_depth',
    ]

    _fields_and_field_types = {
        'camera_source': 'perception_msg/CameraSourceEnum',
        'camera_model': 'perception_msg/CameraModelEnum',
        'score': 'float',
        'index': 'int32',
        'points_2d_x': 'sequence<float>',
        'points_2d_y': 'sequence<float>',
        'points_2d_v': 'sequence<float>',
        'track_id': 'uint32',
        'coefficient_bv': 'sequence<float>',
        'coefficient_bv_sigma': 'sequence<float>',
        'is_failed_3d': 'boolean',
        'lane_type': 'perception_msg/LaneTypeEnum',
        'lane_color': 'perception_msg/LaneColorEnum',
        'lane_width': 'float',
        'is_centerline': 'boolean',
        'points_3d_x': 'sequence<float>',
        'points_3d_y': 'sequence<float>',
        'points_3d_z': 'sequence<float>',
        'is_horizontal_line': 'boolean',
        'lane_horizontal_type': 'perception_msg/LaneHorizontalTypeEnum',
        'stopline_depth': 'float',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['perception_msg', 'msg'], 'CameraSourceEnum'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['perception_msg', 'msg'], 'CameraModelEnum'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('int32'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('float')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('float')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('float')),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('float')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('float')),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['perception_msg', 'msg'], 'LaneTypeEnum'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['perception_msg', 'msg'], 'LaneColorEnum'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('float')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('float')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('float')),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['perception_msg', 'msg'], 'LaneHorizontalTypeEnum'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from perception_msg.msg import CameraSourceEnum
        self.camera_source = kwargs.get('camera_source', CameraSourceEnum())
        from perception_msg.msg import CameraModelEnum
        self.camera_model = kwargs.get('camera_model', CameraModelEnum())
        self.score = kwargs.get('score', float())
        self.index = kwargs.get('index', int())
        self.points_2d_x = array.array('f', kwargs.get('points_2d_x', []))
        self.points_2d_y = array.array('f', kwargs.get('points_2d_y', []))
        self.points_2d_v = array.array('f', kwargs.get('points_2d_v', []))
        self.track_id = kwargs.get('track_id', int())
        self.coefficient_bv = array.array('f', kwargs.get('coefficient_bv', []))
        self.coefficient_bv_sigma = array.array('f', kwargs.get('coefficient_bv_sigma', []))
        self.is_failed_3d = kwargs.get('is_failed_3d', bool())
        from perception_msg.msg import LaneTypeEnum
        self.lane_type = kwargs.get('lane_type', LaneTypeEnum())
        from perception_msg.msg import LaneColorEnum
        self.lane_color = kwargs.get('lane_color', LaneColorEnum())
        self.lane_width = kwargs.get('lane_width', float())
        self.is_centerline = kwargs.get('is_centerline', bool())
        self.points_3d_x = array.array('f', kwargs.get('points_3d_x', []))
        self.points_3d_y = array.array('f', kwargs.get('points_3d_y', []))
        self.points_3d_z = array.array('f', kwargs.get('points_3d_z', []))
        self.is_horizontal_line = kwargs.get('is_horizontal_line', bool())
        from perception_msg.msg import LaneHorizontalTypeEnum
        self.lane_horizontal_type = kwargs.get('lane_horizontal_type', LaneHorizontalTypeEnum())
        self.stopline_depth = kwargs.get('stopline_depth', float())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.camera_source != other.camera_source:
            return False
        if self.camera_model != other.camera_model:
            return False
        if self.score != other.score:
            return False
        if self.index != other.index:
            return False
        if self.points_2d_x != other.points_2d_x:
            return False
        if self.points_2d_y != other.points_2d_y:
            return False
        if self.points_2d_v != other.points_2d_v:
            return False
        if self.track_id != other.track_id:
            return False
        if self.coefficient_bv != other.coefficient_bv:
            return False
        if self.coefficient_bv_sigma != other.coefficient_bv_sigma:
            return False
        if self.is_failed_3d != other.is_failed_3d:
            return False
        if self.lane_type != other.lane_type:
            return False
        if self.lane_color != other.lane_color:
            return False
        if self.lane_width != other.lane_width:
            return False
        if self.is_centerline != other.is_centerline:
            return False
        if self.points_3d_x != other.points_3d_x:
            return False
        if self.points_3d_y != other.points_3d_y:
            return False
        if self.points_3d_z != other.points_3d_z:
            return False
        if self.is_horizontal_line != other.is_horizontal_line:
            return False
        if self.lane_horizontal_type != other.lane_horizontal_type:
            return False
        if self.stopline_depth != other.stopline_depth:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def camera_source(self):
        """Message field 'camera_source'."""
        return self._camera_source

    @camera_source.setter
    def camera_source(self, value):
        if __debug__:
            from perception_msg.msg import CameraSourceEnum
            assert \
                isinstance(value, CameraSourceEnum), \
                "The 'camera_source' field must be a sub message of type 'CameraSourceEnum'"
        self._camera_source = value

    @builtins.property
    def camera_model(self):
        """Message field 'camera_model'."""
        return self._camera_model

    @camera_model.setter
    def camera_model(self, value):
        if __debug__:
            from perception_msg.msg import CameraModelEnum
            assert \
                isinstance(value, CameraModelEnum), \
                "The 'camera_model' field must be a sub message of type 'CameraModelEnum'"
        self._camera_model = value

    @builtins.property
    def score(self):
        """Message field 'score'."""
        return self._score

    @score.setter
    def score(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'score' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'score' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._score = value

    @builtins.property
    def index(self):
        """Message field 'index'."""
        return self._index

    @index.setter
    def index(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'index' field must be of type 'int'"
            assert value >= -2147483648 and value < 2147483648, \
                "The 'index' field must be an integer in [-2147483648, 2147483647]"
        self._index = value

    @builtins.property
    def points_2d_x(self):
        """Message field 'points_2d_x'."""
        return self._points_2d_x

    @points_2d_x.setter
    def points_2d_x(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'f', \
                "The 'points_2d_x' array.array() must have the type code of 'f'"
            self._points_2d_x = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'points_2d_x' field must be a set or sequence and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._points_2d_x = array.array('f', value)

    @builtins.property
    def points_2d_y(self):
        """Message field 'points_2d_y'."""
        return self._points_2d_y

    @points_2d_y.setter
    def points_2d_y(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'f', \
                "The 'points_2d_y' array.array() must have the type code of 'f'"
            self._points_2d_y = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'points_2d_y' field must be a set or sequence and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._points_2d_y = array.array('f', value)

    @builtins.property
    def points_2d_v(self):
        """Message field 'points_2d_v'."""
        return self._points_2d_v

    @points_2d_v.setter
    def points_2d_v(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'f', \
                "The 'points_2d_v' array.array() must have the type code of 'f'"
            self._points_2d_v = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'points_2d_v' field must be a set or sequence and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._points_2d_v = array.array('f', value)

    @builtins.property
    def track_id(self):
        """Message field 'track_id'."""
        return self._track_id

    @track_id.setter
    def track_id(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'track_id' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'track_id' field must be an unsigned integer in [0, 4294967295]"
        self._track_id = value

    @builtins.property
    def coefficient_bv(self):
        """Message field 'coefficient_bv'."""
        return self._coefficient_bv

    @coefficient_bv.setter
    def coefficient_bv(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'f', \
                "The 'coefficient_bv' array.array() must have the type code of 'f'"
            self._coefficient_bv = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'coefficient_bv' field must be a set or sequence and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._coefficient_bv = array.array('f', value)

    @builtins.property
    def coefficient_bv_sigma(self):
        """Message field 'coefficient_bv_sigma'."""
        return self._coefficient_bv_sigma

    @coefficient_bv_sigma.setter
    def coefficient_bv_sigma(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'f', \
                "The 'coefficient_bv_sigma' array.array() must have the type code of 'f'"
            self._coefficient_bv_sigma = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'coefficient_bv_sigma' field must be a set or sequence and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._coefficient_bv_sigma = array.array('f', value)

    @builtins.property
    def is_failed_3d(self):
        """Message field 'is_failed_3d'."""
        return self._is_failed_3d

    @is_failed_3d.setter
    def is_failed_3d(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'is_failed_3d' field must be of type 'bool'"
        self._is_failed_3d = value

    @builtins.property
    def lane_type(self):
        """Message field 'lane_type'."""
        return self._lane_type

    @lane_type.setter
    def lane_type(self, value):
        if __debug__:
            from perception_msg.msg import LaneTypeEnum
            assert \
                isinstance(value, LaneTypeEnum), \
                "The 'lane_type' field must be a sub message of type 'LaneTypeEnum'"
        self._lane_type = value

    @builtins.property
    def lane_color(self):
        """Message field 'lane_color'."""
        return self._lane_color

    @lane_color.setter
    def lane_color(self, value):
        if __debug__:
            from perception_msg.msg import LaneColorEnum
            assert \
                isinstance(value, LaneColorEnum), \
                "The 'lane_color' field must be a sub message of type 'LaneColorEnum'"
        self._lane_color = value

    @builtins.property
    def lane_width(self):
        """Message field 'lane_width'."""
        return self._lane_width

    @lane_width.setter
    def lane_width(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'lane_width' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'lane_width' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._lane_width = value

    @builtins.property
    def is_centerline(self):
        """Message field 'is_centerline'."""
        return self._is_centerline

    @is_centerline.setter
    def is_centerline(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'is_centerline' field must be of type 'bool'"
        self._is_centerline = value

    @builtins.property
    def points_3d_x(self):
        """Message field 'points_3d_x'."""
        return self._points_3d_x

    @points_3d_x.setter
    def points_3d_x(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'f', \
                "The 'points_3d_x' array.array() must have the type code of 'f'"
            self._points_3d_x = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'points_3d_x' field must be a set or sequence and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._points_3d_x = array.array('f', value)

    @builtins.property
    def points_3d_y(self):
        """Message field 'points_3d_y'."""
        return self._points_3d_y

    @points_3d_y.setter
    def points_3d_y(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'f', \
                "The 'points_3d_y' array.array() must have the type code of 'f'"
            self._points_3d_y = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'points_3d_y' field must be a set or sequence and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._points_3d_y = array.array('f', value)

    @builtins.property
    def points_3d_z(self):
        """Message field 'points_3d_z'."""
        return self._points_3d_z

    @points_3d_z.setter
    def points_3d_z(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'f', \
                "The 'points_3d_z' array.array() must have the type code of 'f'"
            self._points_3d_z = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'points_3d_z' field must be a set or sequence and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._points_3d_z = array.array('f', value)

    @builtins.property
    def is_horizontal_line(self):
        """Message field 'is_horizontal_line'."""
        return self._is_horizontal_line

    @is_horizontal_line.setter
    def is_horizontal_line(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'is_horizontal_line' field must be of type 'bool'"
        self._is_horizontal_line = value

    @builtins.property
    def lane_horizontal_type(self):
        """Message field 'lane_horizontal_type'."""
        return self._lane_horizontal_type

    @lane_horizontal_type.setter
    def lane_horizontal_type(self, value):
        if __debug__:
            from perception_msg.msg import LaneHorizontalTypeEnum
            assert \
                isinstance(value, LaneHorizontalTypeEnum), \
                "The 'lane_horizontal_type' field must be a sub message of type 'LaneHorizontalTypeEnum'"
        self._lane_horizontal_type = value

    @builtins.property
    def stopline_depth(self):
        """Message field 'stopline_depth'."""
        return self._stopline_depth

    @stopline_depth.setter
    def stopline_depth(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'stopline_depth' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'stopline_depth' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._stopline_depth = value
