# generated from rosidl_generator_py/resource/_idl.py.em
# with input from sensor_lidar_msg:msg/LidarModeRequest.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_LidarModeRequest(type):
    """Metaclass of message 'LidarModeRequest'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('sensor_lidar_msg')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'sensor_lidar_msg.msg.LidarModeRequest')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__lidar_mode_request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__lidar_mode_request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__lidar_mode_request
            cls._TYPE_SUPPORT = module.type_support_msg__msg__lidar_mode_request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__lidar_mode_request

            from sensor_lidar_msg.msg import LidarID
            if LidarID.__class__._TYPE_SUPPORT is None:
                LidarID.__class__.__import_type_support__()

            from sensor_lidar_msg.msg import LidarMode
            if LidarMode.__class__._TYPE_SUPPORT is None:
                LidarMode.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class LidarModeRequest(metaclass=Metaclass_LidarModeRequest):
    """Message class 'LidarModeRequest'."""

    __slots__ = [
        '_id',
        '_mode',
    ]

    _fields_and_field_types = {
        'id': 'sensor_lidar_msg/LidarID',
        'mode': 'sensor_lidar_msg/LidarMode',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['sensor_lidar_msg', 'msg'], 'LidarID'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['sensor_lidar_msg', 'msg'], 'LidarMode'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from sensor_lidar_msg.msg import LidarID
        self.id = kwargs.get('id', LidarID())
        from sensor_lidar_msg.msg import LidarMode
        self.mode = kwargs.get('mode', LidarMode())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.id != other.id:
            return False
        if self.mode != other.mode:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property  # noqa: A003
    def id(self):  # noqa: A003
        """Message field 'id'."""
        return self._id

    @id.setter  # noqa: A003
    def id(self, value):  # noqa: A003
        if __debug__:
            from sensor_lidar_msg.msg import LidarID
            assert \
                isinstance(value, LidarID), \
                "The 'id' field must be a sub message of type 'LidarID'"
        self._id = value

    @builtins.property
    def mode(self):
        """Message field 'mode'."""
        return self._mode

    @mode.setter
    def mode(self, value):
        if __debug__:
            from sensor_lidar_msg.msg import LidarMode
            assert \
                isinstance(value, LidarMode), \
                "The 'mode' field must be a sub message of type 'LidarMode'"
        self._mode = value
