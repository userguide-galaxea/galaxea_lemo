# generated from rosidl_generator_py/resource/_idl.py.em
# with input from sensor_lidar_msg:msg/LidarCalibrationResult.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_LidarCalibrationResult(type):
    """Metaclass of message 'LidarCalibrationResult'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('sensor_lidar_msg')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'sensor_lidar_msg.msg.LidarCalibrationResult')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__lidar_calibration_result
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__lidar_calibration_result
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__lidar_calibration_result
            cls._TYPE_SUPPORT = module.type_support_msg__msg__lidar_calibration_result
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__lidar_calibration_result

            from sensor_lidar_msg.msg import LidarCalibResult
            if LidarCalibResult.__class__._TYPE_SUPPORT is None:
                LidarCalibResult.__class__.__import_type_support__()

            from sensor_lidar_msg.msg import LidarHorizontResult
            if LidarHorizontResult.__class__._TYPE_SUPPORT is None:
                LidarHorizontResult.__class__.__import_type_support__()

            from sensor_lidar_msg.msg import LidarID
            if LidarID.__class__._TYPE_SUPPORT is None:
                LidarID.__class__.__import_type_support__()

            from sensor_lidar_msg.msg import LidarRotationResult
            if LidarRotationResult.__class__._TYPE_SUPPORT is None:
                LidarRotationResult.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class LidarCalibrationResult(metaclass=Metaclass_LidarCalibrationResult):
    """Message class 'LidarCalibrationResult'."""

    __slots__ = [
        '_id',
        '_calib_result',
        '_horizont_result',
        '_rotation_result',
        '_canmsg_result',
    ]

    _fields_and_field_types = {
        'id': 'sensor_lidar_msg/LidarID',
        'calib_result': 'sensor_lidar_msg/LidarCalibResult',
        'horizont_result': 'sensor_lidar_msg/LidarHorizontResult',
        'rotation_result': 'sensor_lidar_msg/LidarRotationResult',
        'canmsg_result': 'uint8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['sensor_lidar_msg', 'msg'], 'LidarID'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['sensor_lidar_msg', 'msg'], 'LidarCalibResult'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['sensor_lidar_msg', 'msg'], 'LidarHorizontResult'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['sensor_lidar_msg', 'msg'], 'LidarRotationResult'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from sensor_lidar_msg.msg import LidarID
        self.id = kwargs.get('id', LidarID())
        from sensor_lidar_msg.msg import LidarCalibResult
        self.calib_result = kwargs.get('calib_result', LidarCalibResult())
        from sensor_lidar_msg.msg import LidarHorizontResult
        self.horizont_result = kwargs.get('horizont_result', LidarHorizontResult())
        from sensor_lidar_msg.msg import LidarRotationResult
        self.rotation_result = kwargs.get('rotation_result', LidarRotationResult())
        self.canmsg_result = kwargs.get('canmsg_result', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.id != other.id:
            return False
        if self.calib_result != other.calib_result:
            return False
        if self.horizont_result != other.horizont_result:
            return False
        if self.rotation_result != other.rotation_result:
            return False
        if self.canmsg_result != other.canmsg_result:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property  # noqa: A003
    def id(self):  # noqa: A003
        """Message field 'id'."""
        return self._id

    @id.setter  # noqa: A003
    def id(self, value):  # noqa: A003
        if __debug__:
            from sensor_lidar_msg.msg import LidarID
            assert \
                isinstance(value, LidarID), \
                "The 'id' field must be a sub message of type 'LidarID'"
        self._id = value

    @builtins.property
    def calib_result(self):
        """Message field 'calib_result'."""
        return self._calib_result

    @calib_result.setter
    def calib_result(self, value):
        if __debug__:
            from sensor_lidar_msg.msg import LidarCalibResult
            assert \
                isinstance(value, LidarCalibResult), \
                "The 'calib_result' field must be a sub message of type 'LidarCalibResult'"
        self._calib_result = value

    @builtins.property
    def horizont_result(self):
        """Message field 'horizont_result'."""
        return self._horizont_result

    @horizont_result.setter
    def horizont_result(self, value):
        if __debug__:
            from sensor_lidar_msg.msg import LidarHorizontResult
            assert \
                isinstance(value, LidarHorizontResult), \
                "The 'horizont_result' field must be a sub message of type 'LidarHorizontResult'"
        self._horizont_result = value

    @builtins.property
    def rotation_result(self):
        """Message field 'rotation_result'."""
        return self._rotation_result

    @rotation_result.setter
    def rotation_result(self, value):
        if __debug__:
            from sensor_lidar_msg.msg import LidarRotationResult
            assert \
                isinstance(value, LidarRotationResult), \
                "The 'rotation_result' field must be a sub message of type 'LidarRotationResult'"
        self._rotation_result = value

    @builtins.property
    def canmsg_result(self):
        """Message field 'canmsg_result'."""
        return self._canmsg_result

    @canmsg_result.setter
    def canmsg_result(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'canmsg_result' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'canmsg_result' field must be an unsigned integer in [0, 255]"
        self._canmsg_result = value
