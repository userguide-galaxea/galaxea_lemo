#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to sensor_lidar_msg__msg__LidarCalibResult

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarCalibResult {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LidarCalibResult {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarCalibResult::default())
  }
}

impl rosidl_runtime_rs::Message for LidarCalibResult {
  type RmwMsg = super::msg::rmw::LidarCalibResult;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarCalibrationProgressResult

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarCalibrationProgressResult {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LidarCalibrationProgressResult {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarCalibrationProgressResult::default())
  }
}

impl rosidl_runtime_rs::Message for LidarCalibrationProgressResult {
  type RmwMsg = super::msg::rmw::LidarCalibrationProgressResult;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarCalibrationResult

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarCalibrationResult {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: super::msg::LidarID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub calib_result: super::msg::LidarCalibResult,


    // This member is not documented.
    #[allow(missing_docs)]
    pub horizont_result: super::msg::LidarHorizontResult,


    // This member is not documented.
    #[allow(missing_docs)]
    pub rotation_result: super::msg::LidarRotationResult,


    // This member is not documented.
    #[allow(missing_docs)]
    pub canmsg_result: u8,

}



impl Default for LidarCalibrationResult {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarCalibrationResult::default())
  }
}

impl rosidl_runtime_rs::Message for LidarCalibrationResult {
  type RmwMsg = super::msg::rmw::LidarCalibrationResult;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: super::msg::LidarID::into_rmw_message(std::borrow::Cow::Owned(msg.id)).into_owned(),
        calib_result: super::msg::LidarCalibResult::into_rmw_message(std::borrow::Cow::Owned(msg.calib_result)).into_owned(),
        horizont_result: super::msg::LidarHorizontResult::into_rmw_message(std::borrow::Cow::Owned(msg.horizont_result)).into_owned(),
        rotation_result: super::msg::LidarRotationResult::into_rmw_message(std::borrow::Cow::Owned(msg.rotation_result)).into_owned(),
        canmsg_result: msg.canmsg_result,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: super::msg::LidarID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.id)).into_owned(),
        calib_result: super::msg::LidarCalibResult::into_rmw_message(std::borrow::Cow::Borrowed(&msg.calib_result)).into_owned(),
        horizont_result: super::msg::LidarHorizontResult::into_rmw_message(std::borrow::Cow::Borrowed(&msg.horizont_result)).into_owned(),
        rotation_result: super::msg::LidarRotationResult::into_rmw_message(std::borrow::Cow::Borrowed(&msg.rotation_result)).into_owned(),
      canmsg_result: msg.canmsg_result,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      id: super::msg::LidarID::from_rmw_message(msg.id),
      calib_result: super::msg::LidarCalibResult::from_rmw_message(msg.calib_result),
      horizont_result: super::msg::LidarHorizontResult::from_rmw_message(msg.horizont_result),
      rotation_result: super::msg::LidarRotationResult::from_rmw_message(msg.rotation_result),
      canmsg_result: msg.canmsg_result,
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarCalibrationResultRequest

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarCalibrationResultRequest {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: super::msg::LidarID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_: super::msg::LidarCalibrationType,

}



impl Default for LidarCalibrationResultRequest {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarCalibrationResultRequest::default())
  }
}

impl rosidl_runtime_rs::Message for LidarCalibrationResultRequest {
  type RmwMsg = super::msg::rmw::LidarCalibrationResultRequest;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: super::msg::LidarID::into_rmw_message(std::borrow::Cow::Owned(msg.id)).into_owned(),
        type_: super::msg::LidarCalibrationType::into_rmw_message(std::borrow::Cow::Owned(msg.type_)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: super::msg::LidarID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.id)).into_owned(),
        type_: super::msg::LidarCalibrationType::into_rmw_message(std::borrow::Cow::Borrowed(&msg.type_)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      id: super::msg::LidarID::from_rmw_message(msg.id),
      type_: super::msg::LidarCalibrationType::from_rmw_message(msg.type_),
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarCalibrationResultResponse

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarCalibrationResultResponse {

    // This member is not documented.
    #[allow(missing_docs)]
    pub calib_result_res: Vec<super::msg::LidarCalibrationResult>,

}



impl Default for LidarCalibrationResultResponse {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarCalibrationResultResponse::default())
  }
}

impl rosidl_runtime_rs::Message for LidarCalibrationResultResponse {
  type RmwMsg = super::msg::rmw::LidarCalibrationResultResponse;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        calib_result_res: msg.calib_result_res
          .into_iter()
          .map(|elem| super::msg::LidarCalibrationResult::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        calib_result_res: msg.calib_result_res
          .iter()
          .map(|elem| super::msg::LidarCalibrationResult::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      calib_result_res: msg.calib_result_res
          .into_iter()
          .map(super::msg::LidarCalibrationResult::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarCalibrationType

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarCalibrationType {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LidarCalibrationType {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarCalibrationType::default())
  }
}

impl rosidl_runtime_rs::Message for LidarCalibrationType {
  type RmwMsg = super::msg::rmw::LidarCalibrationType;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarError

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarError {

    // This member is not documented.
    #[allow(missing_docs)]
    pub mems_initialization_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mems_operating_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_transmitting_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_receiving_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_fusa_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub window_contamination_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sun_blind_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub window_heating_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_internal_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_external_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_internal_volt_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_temp_err: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub clock_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sync_err: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved1: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub reserved2: u8,

}



impl Default for LidarError {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarError::default())
  }
}

impl rosidl_runtime_rs::Message for LidarError {
  type RmwMsg = super::msg::rmw::LidarError;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        mems_initialization_err: msg.mems_initialization_err,
        mems_operating_err: msg.mems_operating_err,
        lidar_transmitting_err: msg.lidar_transmitting_err,
        lidar_receiving_err: msg.lidar_receiving_err,
        lidar_fusa_err: msg.lidar_fusa_err,
        window_contamination_err: msg.window_contamination_err,
        sun_blind_err: msg.sun_blind_err,
        window_heating_err: msg.window_heating_err,
        lidar_internal_err: msg.lidar_internal_err,
        lidar_external_err: msg.lidar_external_err,
        lidar_internal_volt_err: msg.lidar_internal_volt_err,
        lidar_temp_err: msg.lidar_temp_err,
        clock_err: msg.clock_err,
        sync_err: msg.sync_err,
        reserved1: msg.reserved1,
        reserved2: msg.reserved2,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      mems_initialization_err: msg.mems_initialization_err,
      mems_operating_err: msg.mems_operating_err,
      lidar_transmitting_err: msg.lidar_transmitting_err,
      lidar_receiving_err: msg.lidar_receiving_err,
      lidar_fusa_err: msg.lidar_fusa_err,
      window_contamination_err: msg.window_contamination_err,
      sun_blind_err: msg.sun_blind_err,
      window_heating_err: msg.window_heating_err,
      lidar_internal_err: msg.lidar_internal_err,
      lidar_external_err: msg.lidar_external_err,
      lidar_internal_volt_err: msg.lidar_internal_volt_err,
      lidar_temp_err: msg.lidar_temp_err,
      clock_err: msg.clock_err,
      sync_err: msg.sync_err,
      reserved1: msg.reserved1,
      reserved2: msg.reserved2,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      mems_initialization_err: msg.mems_initialization_err,
      mems_operating_err: msg.mems_operating_err,
      lidar_transmitting_err: msg.lidar_transmitting_err,
      lidar_receiving_err: msg.lidar_receiving_err,
      lidar_fusa_err: msg.lidar_fusa_err,
      window_contamination_err: msg.window_contamination_err,
      sun_blind_err: msg.sun_blind_err,
      window_heating_err: msg.window_heating_err,
      lidar_internal_err: msg.lidar_internal_err,
      lidar_external_err: msg.lidar_external_err,
      lidar_internal_volt_err: msg.lidar_internal_volt_err,
      lidar_temp_err: msg.lidar_temp_err,
      clock_err: msg.clock_err,
      sync_err: msg.sync_err,
      reserved1: msg.reserved1,
      reserved2: msg.reserved2,
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarErrorReport

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarErrorReport {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: super::msg::LidarID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub error_mode: u32,

}



impl Default for LidarErrorReport {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarErrorReport::default())
  }
}

impl rosidl_runtime_rs::Message for LidarErrorReport {
  type RmwMsg = super::msg::rmw::LidarErrorReport;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: super::msg::LidarID::into_rmw_message(std::borrow::Cow::Owned(msg.id)).into_owned(),
        error_mode: msg.error_mode,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: super::msg::LidarID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.id)).into_owned(),
      error_mode: msg.error_mode,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      id: super::msg::LidarID::from_rmw_message(msg.id),
      error_mode: msg.error_mode,
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarErrorStatus

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarErrorStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub status: Vec<super::msg::LidarErrorReport>,

}



impl Default for LidarErrorStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarErrorStatus::default())
  }
}

impl rosidl_runtime_rs::Message for LidarErrorStatus {
  type RmwMsg = super::msg::rmw::LidarErrorStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status
          .into_iter()
          .map(|elem| super::msg::LidarErrorReport::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        status: msg.status
          .iter()
          .map(|elem| super::msg::LidarErrorReport::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      status: msg.status
          .into_iter()
          .map(super::msg::LidarErrorReport::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarHorizontResult

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarHorizontResult {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LidarHorizontResult {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarHorizontResult::default())
  }
}

impl rosidl_runtime_rs::Message for LidarHorizontResult {
  type RmwMsg = super::msg::rmw::LidarHorizontResult;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarID

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarID {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u32,

}



impl Default for LidarID {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarID::default())
  }
}

impl rosidl_runtime_rs::Message for LidarID {
  type RmwMsg = super::msg::rmw::LidarID;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarMode

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarMode {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LidarMode {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarMode::default())
  }
}

impl rosidl_runtime_rs::Message for LidarMode {
  type RmwMsg = super::msg::rmw::LidarMode;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarModeRequest

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarModeRequest {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: super::msg::LidarID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mode: super::msg::LidarMode,

}



impl Default for LidarModeRequest {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarModeRequest::default())
  }
}

impl rosidl_runtime_rs::Message for LidarModeRequest {
  type RmwMsg = super::msg::rmw::LidarModeRequest;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: super::msg::LidarID::into_rmw_message(std::borrow::Cow::Owned(msg.id)).into_owned(),
        mode: super::msg::LidarMode::into_rmw_message(std::borrow::Cow::Owned(msg.mode)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: super::msg::LidarID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.id)).into_owned(),
        mode: super::msg::LidarMode::into_rmw_message(std::borrow::Cow::Borrowed(&msg.mode)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      id: super::msg::LidarID::from_rmw_message(msg.id),
      mode: super::msg::LidarMode::from_rmw_message(msg.mode),
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarModeResponse

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarModeResponse {

    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_mode_resp: Vec<super::msg::LidarModeRequest>,

}



impl Default for LidarModeResponse {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarModeResponse::default())
  }
}

impl rosidl_runtime_rs::Message for LidarModeResponse {
  type RmwMsg = super::msg::rmw::LidarModeResponse;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        lidar_mode_resp: msg.lidar_mode_resp
          .into_iter()
          .map(|elem| super::msg::LidarModeRequest::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        lidar_mode_resp: msg.lidar_mode_resp
          .iter()
          .map(|elem| super::msg::LidarModeRequest::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      lidar_mode_resp: msg.lidar_mode_resp
          .into_iter()
          .map(super::msg::LidarModeRequest::from_rmw_message)
          .collect(),
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarNotificationAck

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarNotificationAck {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: super::msg::LidarID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub ack: u8,

}



impl Default for LidarNotificationAck {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarNotificationAck::default())
  }
}

impl rosidl_runtime_rs::Message for LidarNotificationAck {
  type RmwMsg = super::msg::rmw::LidarNotificationAck;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: super::msg::LidarID::into_rmw_message(std::borrow::Cow::Owned(msg.id)).into_owned(),
        value: msg.value,
        ack: msg.ack,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: super::msg::LidarID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.id)).into_owned(),
      value: msg.value,
      ack: msg.ack,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      id: super::msg::LidarID::from_rmw_message(msg.id),
      value: msg.value,
      ack: msg.ack,
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarRotationResult

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarRotationResult {

    // This member is not documented.
    #[allow(missing_docs)]
    pub value: u8,

}



impl Default for LidarRotationResult {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarRotationResult::default())
  }
}

impl rosidl_runtime_rs::Message for LidarRotationResult {
  type RmwMsg = super::msg::rmw::LidarRotationResult;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        value: msg.value,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      value: msg.value,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      value: msg.value,
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarStatus

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: super::msg::LidarID,


    // This member is not documented.
    #[allow(missing_docs)]
    pub progress_result: super::msg::LidarCalibrationProgressResult,


    // This member is not documented.
    #[allow(missing_docs)]
    pub calib_progress: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub error: super::msg::LidarError,


    // This member is not documented.
    #[allow(missing_docs)]
    pub calib_mode: u32,

}



impl Default for LidarStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarStatus::default())
  }
}

impl rosidl_runtime_rs::Message for LidarStatus {
  type RmwMsg = super::msg::rmw::LidarStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: super::msg::LidarID::into_rmw_message(std::borrow::Cow::Owned(msg.id)).into_owned(),
        progress_result: super::msg::LidarCalibrationProgressResult::into_rmw_message(std::borrow::Cow::Owned(msg.progress_result)).into_owned(),
        calib_progress: msg.calib_progress,
        error: super::msg::LidarError::into_rmw_message(std::borrow::Cow::Owned(msg.error)).into_owned(),
        calib_mode: msg.calib_mode,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        id: super::msg::LidarID::into_rmw_message(std::borrow::Cow::Borrowed(&msg.id)).into_owned(),
        progress_result: super::msg::LidarCalibrationProgressResult::into_rmw_message(std::borrow::Cow::Borrowed(&msg.progress_result)).into_owned(),
      calib_progress: msg.calib_progress,
        error: super::msg::LidarError::into_rmw_message(std::borrow::Cow::Borrowed(&msg.error)).into_owned(),
      calib_mode: msg.calib_mode,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      id: super::msg::LidarID::from_rmw_message(msg.id),
      progress_result: super::msg::LidarCalibrationProgressResult::from_rmw_message(msg.progress_result),
      calib_progress: msg.calib_progress,
      error: super::msg::LidarError::from_rmw_message(msg.error),
      calib_mode: msg.calib_mode,
    }
  }
}


// Corresponds to sensor_lidar_msg__msg__LidarStatusReport

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct LidarStatusReport {

    // This member is not documented.
    #[allow(missing_docs)]
    pub lidar_service_mode: super::msg::LidarMode,


    // This member is not documented.
    #[allow(missing_docs)]
    pub status: Vec<super::msg::LidarStatus>,

}



impl Default for LidarStatusReport {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::LidarStatusReport::default())
  }
}

impl rosidl_runtime_rs::Message for LidarStatusReport {
  type RmwMsg = super::msg::rmw::LidarStatusReport;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        lidar_service_mode: super::msg::LidarMode::into_rmw_message(std::borrow::Cow::Owned(msg.lidar_service_mode)).into_owned(),
        status: msg.status
          .into_iter()
          .map(|elem| super::msg::LidarStatus::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        lidar_service_mode: super::msg::LidarMode::into_rmw_message(std::borrow::Cow::Borrowed(&msg.lidar_service_mode)).into_owned(),
        status: msg.status
          .iter()
          .map(|elem| super::msg::LidarStatus::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      lidar_service_mode: super::msg::LidarMode::from_rmw_message(msg.lidar_service_mode),
      status: msg.status
          .into_iter()
          .map(super::msg::LidarStatus::from_rmw_message)
          .collect(),
    }
  }
}


