#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to graph_msgs__msg__Edges
/// base-zero index of all the verticies this particular vertice connects to (edges)

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Edges {

    // This member is not documented.
    #[allow(missing_docs)]
    pub node_ids: Vec<u32>,

    /// optional cost/weight of each edge. if vector is empty assume all weights are equal (1)
    pub weights: Vec<f64>,

}



impl Default for Edges {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::Edges::default())
  }
}

impl rosidl_runtime_rs::Message for Edges {
  type RmwMsg = super::msg::rmw::Edges;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        node_ids: msg.node_ids.into(),
        weights: msg.weights.into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        node_ids: msg.node_ids.as_slice().into(),
        weights: msg.weights.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      node_ids: msg.node_ids
          .into_iter()
          .collect(),
      weights: msg.weights
          .into_iter()
          .collect(),
    }
  }
}


// Corresponds to graph_msgs__msg__GeometryGraph
/// A reference coordinate frame and timestamp

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GeometryGraph {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,

    /// 3D spacial graph
    pub nodes: Vec<geometry_msgs::msg::Point>,

    /// This vector should be the same length as nodes, above, and represents all the connecting nodes
    pub edges: Vec<super::msg::Edges>,

}



impl Default for GeometryGraph {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::GeometryGraph::default())
  }
}

impl rosidl_runtime_rs::Message for GeometryGraph {
  type RmwMsg = super::msg::rmw::GeometryGraph;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        nodes: msg.nodes
          .into_iter()
          .map(|elem| geometry_msgs::msg::Point::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
        edges: msg.edges
          .into_iter()
          .map(|elem| super::msg::Edges::into_rmw_message(std::borrow::Cow::Owned(elem)).into_owned())
          .collect(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        nodes: msg.nodes
          .iter()
          .map(|elem| geometry_msgs::msg::Point::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
        edges: msg.edges
          .iter()
          .map(|elem| super::msg::Edges::into_rmw_message(std::borrow::Cow::Borrowed(elem)).into_owned())
          .collect(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      nodes: msg.nodes
          .into_iter()
          .map(geometry_msgs::msg::Point::from_rmw_message)
          .collect(),
      edges: msg.edges
          .into_iter()
          .map(super::msg::Edges::from_rmw_message)
          .collect(),
    }
  }
}


