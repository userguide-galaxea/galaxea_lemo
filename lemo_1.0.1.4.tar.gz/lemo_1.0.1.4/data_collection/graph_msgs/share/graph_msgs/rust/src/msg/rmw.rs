#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "graph_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__graph_msgs__msg__Edges() -> *const std::ffi::c_void;
}

#[link(name = "graph_msgs__rosidl_generator_c")]
extern "C" {
    fn graph_msgs__msg__Edges__init(msg: *mut Edges) -> bool;
    fn graph_msgs__msg__Edges__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Edges>, size: usize) -> bool;
    fn graph_msgs__msg__Edges__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Edges>);
    fn graph_msgs__msg__Edges__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Edges>, out_seq: *mut rosidl_runtime_rs::Sequence<Edges>) -> bool;
}

// Corresponds to graph_msgs__msg__Edges
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// base-zero index of all the verticies this particular vertice connects to (edges)

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Edges {

    // This member is not documented.
    #[allow(missing_docs)]
    pub node_ids: rosidl_runtime_rs::Sequence<u32>,

    /// optional cost/weight of each edge. if vector is empty assume all weights are equal (1)
    pub weights: rosidl_runtime_rs::Sequence<f64>,

}



impl Default for Edges {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !graph_msgs__msg__Edges__init(&mut msg as *mut _) {
        panic!("Call to graph_msgs__msg__Edges__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Edges {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { graph_msgs__msg__Edges__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { graph_msgs__msg__Edges__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { graph_msgs__msg__Edges__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Edges {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Edges where Self: Sized {
  const TYPE_NAME: &'static str = "graph_msgs/msg/Edges";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__graph_msgs__msg__Edges() }
  }
}


#[link(name = "graph_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__graph_msgs__msg__GeometryGraph() -> *const std::ffi::c_void;
}

#[link(name = "graph_msgs__rosidl_generator_c")]
extern "C" {
    fn graph_msgs__msg__GeometryGraph__init(msg: *mut GeometryGraph) -> bool;
    fn graph_msgs__msg__GeometryGraph__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GeometryGraph>, size: usize) -> bool;
    fn graph_msgs__msg__GeometryGraph__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GeometryGraph>);
    fn graph_msgs__msg__GeometryGraph__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GeometryGraph>, out_seq: *mut rosidl_runtime_rs::Sequence<GeometryGraph>) -> bool;
}

// Corresponds to graph_msgs__msg__GeometryGraph
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// A reference coordinate frame and timestamp

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GeometryGraph {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,

    /// 3D spacial graph
    pub nodes: rosidl_runtime_rs::Sequence<geometry_msgs::msg::rmw::Point>,

    /// This vector should be the same length as nodes, above, and represents all the connecting nodes
    pub edges: rosidl_runtime_rs::Sequence<super::super::msg::rmw::Edges>,

}



impl Default for GeometryGraph {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !graph_msgs__msg__GeometryGraph__init(&mut msg as *mut _) {
        panic!("Call to graph_msgs__msg__GeometryGraph__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GeometryGraph {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { graph_msgs__msg__GeometryGraph__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { graph_msgs__msg__GeometryGraph__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { graph_msgs__msg__GeometryGraph__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GeometryGraph {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GeometryGraph where Self: Sized {
  const TYPE_NAME: &'static str = "graph_msgs/msg/GeometryGraph";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__graph_msgs__msg__GeometryGraph() }
  }
}


