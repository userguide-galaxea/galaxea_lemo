# generated from rosidl_cmake/cmake/rosidl_cmake_aggregate_target-extras.cmake.in

# Create a convenience aggregate target g4_spi::g4_spi
# that links all generated interface targets, so downstream packages can use
# a single modern CMake target name instead of ${g4_spi_TARGETS}.
if(g4_spi_TARGETS AND NOT TARGET g4_spi::g4_spi)
  add_library(g4_spi::g4_spi INTERFACE IMPORTED)
  set_target_properties(g4_spi::g4_spi PROPERTIES
    INTERFACE_LINK_LIBRARIES "${g4_spi_TARGETS}")
endif()
