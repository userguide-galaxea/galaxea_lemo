#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "g4_spi__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__MotorCanFrame() -> *const std::ffi::c_void;
}

#[link(name = "g4_spi__rosidl_generator_c")]
extern "C" {
    fn g4_spi__msg__MotorCanFrame__init(msg: *mut MotorCanFrame) -> bool;
    fn g4_spi__msg__MotorCanFrame__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<MotorCanFrame>, size: usize) -> bool;
    fn g4_spi__msg__MotorCanFrame__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<MotorCanFrame>);
    fn g4_spi__msg__MotorCanFrame__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<MotorCanFrame>, out_seq: *mut rosidl_runtime_rs::Sequence<MotorCanFrame>) -> bool;
}

// Corresponds to g4_spi__msg__MotorCanFrame
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// One-byte motor identifier.

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MotorCanFrame {

    // This member is not documented.
    #[allow(missing_docs)]
    pub id: u16,

    /// Eight-byte CAN data payload.
    pub data: [u8; 8],

}



impl Default for MotorCanFrame {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !g4_spi__msg__MotorCanFrame__init(&mut msg as *mut _) {
        panic!("Call to g4_spi__msg__MotorCanFrame__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for MotorCanFrame {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__MotorCanFrame__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__MotorCanFrame__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__MotorCanFrame__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for MotorCanFrame {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for MotorCanFrame where Self: Sized {
  const TYPE_NAME: &'static str = "g4_spi/msg/MotorCanFrame";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__MotorCanFrame() }
  }
}


#[link(name = "g4_spi__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__MotorData() -> *const std::ffi::c_void;
}

#[link(name = "g4_spi__rosidl_generator_c")]
extern "C" {
    fn g4_spi__msg__MotorData__init(msg: *mut MotorData) -> bool;
    fn g4_spi__msg__MotorData__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<MotorData>, size: usize) -> bool;
    fn g4_spi__msg__MotorData__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<MotorData>);
    fn g4_spi__msg__MotorData__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<MotorData>, out_seq: *mut rosidl_runtime_rs::Sequence<MotorData>) -> bool;
}

// Corresponds to g4_spi__msg__MotorData
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct MotorData {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub can_id: u16,


    // This member is not documented.
    #[allow(missing_docs)]
    pub arm_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: rosidl_runtime_rs::Sequence<u8>,

}



impl Default for MotorData {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !g4_spi__msg__MotorData__init(&mut msg as *mut _) {
        panic!("Call to g4_spi__msg__MotorData__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for MotorData {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__MotorData__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__MotorData__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__MotorData__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for MotorData {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for MotorData where Self: Sized {
  const TYPE_NAME: &'static str = "g4_spi/msg/MotorData";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__MotorData() }
  }
}


#[link(name = "g4_spi__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__A1zFrame() -> *const std::ffi::c_void;
}

#[link(name = "g4_spi__rosidl_generator_c")]
extern "C" {
    fn g4_spi__msg__A1zFrame__init(msg: *mut A1zFrame) -> bool;
    fn g4_spi__msg__A1zFrame__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<A1zFrame>, size: usize) -> bool;
    fn g4_spi__msg__A1zFrame__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<A1zFrame>);
    fn g4_spi__msg__A1zFrame__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<A1zFrame>, out_seq: *mut rosidl_runtime_rs::Sequence<A1zFrame>) -> bool;
}

// Corresponds to g4_spi__msg__A1zFrame
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// CAN data for motors 1 through 6. Motor IDs are 1 through 6.

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct A1zFrame {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,

    /// 1是左臂，2是右臂
    pub arm_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub motors: [super::super::msg::rmw::MotorCanFrame; 6],

}



impl Default for A1zFrame {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !g4_spi__msg__A1zFrame__init(&mut msg as *mut _) {
        panic!("Call to g4_spi__msg__A1zFrame__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for A1zFrame {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__A1zFrame__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__A1zFrame__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__A1zFrame__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for A1zFrame {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for A1zFrame where Self: Sized {
  const TYPE_NAME: &'static str = "g4_spi/msg/A1zFrame";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__A1zFrame() }
  }
}


#[link(name = "g4_spi__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__A1zLeaderStatus() -> *const std::ffi::c_void;
}

#[link(name = "g4_spi__rosidl_generator_c")]
extern "C" {
    fn g4_spi__msg__A1zLeaderStatus__init(msg: *mut A1zLeaderStatus) -> bool;
    fn g4_spi__msg__A1zLeaderStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<A1zLeaderStatus>, size: usize) -> bool;
    fn g4_spi__msg__A1zLeaderStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<A1zLeaderStatus>);
    fn g4_spi__msg__A1zLeaderStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<A1zLeaderStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<A1zLeaderStatus>) -> bool;
}

// Corresponds to g4_spi__msg__A1zLeaderStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// Bit i in each valid mask indicates whether device i (1..7) is connected.

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct A1zLeaderStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub left_connect_mask: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub left_servo_error: [u8; 7],


    // This member is not documented.
    #[allow(missing_docs)]
    pub right_connect_mask: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub right_servo_error: [u8; 7],

}



impl Default for A1zLeaderStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !g4_spi__msg__A1zLeaderStatus__init(&mut msg as *mut _) {
        panic!("Call to g4_spi__msg__A1zLeaderStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for A1zLeaderStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__A1zLeaderStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__A1zLeaderStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__A1zLeaderStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for A1zLeaderStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for A1zLeaderStatus where Self: Sized {
  const TYPE_NAME: &'static str = "g4_spi/msg/A1zLeaderStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__A1zLeaderStatus() }
  }
}


#[link(name = "g4_spi__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__Claw() -> *const std::ffi::c_void;
}

#[link(name = "g4_spi__rosidl_generator_c")]
extern "C" {
    fn g4_spi__msg__Claw__init(msg: *mut Claw) -> bool;
    fn g4_spi__msg__Claw__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Claw>, size: usize) -> bool;
    fn g4_spi__msg__Claw__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Claw>);
    fn g4_spi__msg__Claw__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Claw>, out_seq: *mut rosidl_runtime_rs::Sequence<Claw>) -> bool;
}

// Corresponds to g4_spi__msg__Claw
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// Claw state byte from the final byte of an A1Z frame.

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Claw {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: [u8; 8],

}



impl Default for Claw {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !g4_spi__msg__Claw__init(&mut msg as *mut _) {
        panic!("Call to g4_spi__msg__Claw__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Claw {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__Claw__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__Claw__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__Claw__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Claw {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Claw where Self: Sized {
  const TYPE_NAME: &'static str = "g4_spi/msg/Claw";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__Claw() }
  }
}


#[link(name = "g4_spi__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__ServoStates() -> *const std::ffi::c_void;
}

#[link(name = "g4_spi__rosidl_generator_c")]
extern "C" {
    fn g4_spi__msg__ServoStates__init(msg: *mut ServoStates) -> bool;
    fn g4_spi__msg__ServoStates__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ServoStates>, size: usize) -> bool;
    fn g4_spi__msg__ServoStates__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ServoStates>);
    fn g4_spi__msg__ServoStates__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ServoStates>, out_seq: *mut rosidl_runtime_rs::Sequence<ServoStates>) -> bool;
}

// Corresponds to g4_spi__msg__ServoStates
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// Seven servos; fields at the same index belong to the same servo.

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ServoStates {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub position: [u32; 7],


    // This member is not documented.
    #[allow(missing_docs)]
    pub velocity: [i32; 7],

}



impl Default for ServoStates {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !g4_spi__msg__ServoStates__init(&mut msg as *mut _) {
        panic!("Call to g4_spi__msg__ServoStates__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ServoStates {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__ServoStates__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__ServoStates__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__ServoStates__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ServoStates {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ServoStates where Self: Sized {
  const TYPE_NAME: &'static str = "g4_spi/msg/ServoStates";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__ServoStates() }
  }
}


#[link(name = "g4_spi__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__KeyMsg() -> *const std::ffi::c_void;
}

#[link(name = "g4_spi__rosidl_generator_c")]
extern "C" {
    fn g4_spi__msg__KeyMsg__init(msg: *mut KeyMsg) -> bool;
    fn g4_spi__msg__KeyMsg__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<KeyMsg>, size: usize) -> bool;
    fn g4_spi__msg__KeyMsg__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<KeyMsg>);
    fn g4_spi__msg__KeyMsg__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<KeyMsg>, out_seq: *mut rosidl_runtime_rs::Sequence<KeyMsg>) -> bool;
}

// Corresponds to g4_spi__msg__KeyMsg
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct KeyMsg {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub raw_x: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub raw_y: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub keyyg_pressed: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub three_mode: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub key_pressed: u8,

}



impl Default for KeyMsg {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !g4_spi__msg__KeyMsg__init(&mut msg as *mut _) {
        panic!("Call to g4_spi__msg__KeyMsg__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for KeyMsg {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__KeyMsg__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__KeyMsg__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__KeyMsg__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for KeyMsg {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for KeyMsg where Self: Sized {
  const TYPE_NAME: &'static str = "g4_spi/msg/KeyMsg";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__KeyMsg() }
  }
}


#[link(name = "g4_spi__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__ServoCtrl() -> *const std::ffi::c_void;
}

#[link(name = "g4_spi__rosidl_generator_c")]
extern "C" {
    fn g4_spi__msg__ServoCtrl__init(msg: *mut ServoCtrl) -> bool;
    fn g4_spi__msg__ServoCtrl__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ServoCtrl>, size: usize) -> bool;
    fn g4_spi__msg__ServoCtrl__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ServoCtrl>);
    fn g4_spi__msg__ServoCtrl__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ServoCtrl>, out_seq: *mut rosidl_runtime_rs::Sequence<ServoCtrl>) -> bool;
}

// Corresponds to g4_spi__msg__ServoCtrl
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ServoCtrl {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub arm_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub servo_id: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub cmd: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub length: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: rosidl_runtime_rs::Sequence<u8>,

}



impl Default for ServoCtrl {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !g4_spi__msg__ServoCtrl__init(&mut msg as *mut _) {
        panic!("Call to g4_spi__msg__ServoCtrl__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ServoCtrl {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__ServoCtrl__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__ServoCtrl__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { g4_spi__msg__ServoCtrl__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ServoCtrl {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ServoCtrl where Self: Sized {
  const TYPE_NAME: &'static str = "g4_spi/msg/ServoCtrl";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__g4_spi__msg__ServoCtrl() }
  }
}


