# generated from rosidl_generator_py/resource/_idl.py.em
# with input from g4_spi:msg/KeyMsg.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_KeyMsg(type):
    """Metaclass of message 'KeyMsg'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('g4_spi')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'g4_spi.msg.KeyMsg')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__key_msg
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__key_msg
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__key_msg
            cls._TYPE_SUPPORT = module.type_support_msg__msg__key_msg
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__key_msg

            from std_msgs.msg import Header
            if Header.__class__._TYPE_SUPPORT is None:
                Header.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class KeyMsg(metaclass=Metaclass_KeyMsg):
    """Message class 'KeyMsg'."""

    __slots__ = [
        '_header',
        '_raw_x',
        '_raw_y',
        '_keyyg_pressed',
        '_three_mode',
        '_key_pressed',
    ]

    _fields_and_field_types = {
        'header': 'std_msgs/Header',
        'raw_x': 'uint32',
        'raw_y': 'uint32',
        'keyyg_pressed': 'uint8',
        'three_mode': 'uint8',
        'key_pressed': 'uint8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Header'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from std_msgs.msg import Header
        self.header = kwargs.get('header', Header())
        self.raw_x = kwargs.get('raw_x', int())
        self.raw_y = kwargs.get('raw_y', int())
        self.keyyg_pressed = kwargs.get('keyyg_pressed', int())
        self.three_mode = kwargs.get('three_mode', int())
        self.key_pressed = kwargs.get('key_pressed', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.header != other.header:
            return False
        if self.raw_x != other.raw_x:
            return False
        if self.raw_y != other.raw_y:
            return False
        if self.keyyg_pressed != other.keyyg_pressed:
            return False
        if self.three_mode != other.three_mode:
            return False
        if self.key_pressed != other.key_pressed:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def header(self):
        """Message field 'header'."""
        return self._header

    @header.setter
    def header(self, value):
        if __debug__:
            from std_msgs.msg import Header
            assert \
                isinstance(value, Header), \
                "The 'header' field must be a sub message of type 'Header'"
        self._header = value

    @builtins.property
    def raw_x(self):
        """Message field 'raw_x'."""
        return self._raw_x

    @raw_x.setter
    def raw_x(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'raw_x' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'raw_x' field must be an unsigned integer in [0, 4294967295]"
        self._raw_x = value

    @builtins.property
    def raw_y(self):
        """Message field 'raw_y'."""
        return self._raw_y

    @raw_y.setter
    def raw_y(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'raw_y' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'raw_y' field must be an unsigned integer in [0, 4294967295]"
        self._raw_y = value

    @builtins.property
    def keyyg_pressed(self):
        """Message field 'keyyg_pressed'."""
        return self._keyyg_pressed

    @keyyg_pressed.setter
    def keyyg_pressed(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'keyyg_pressed' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'keyyg_pressed' field must be an unsigned integer in [0, 255]"
        self._keyyg_pressed = value

    @builtins.property
    def three_mode(self):
        """Message field 'three_mode'."""
        return self._three_mode

    @three_mode.setter
    def three_mode(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'three_mode' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'three_mode' field must be an unsigned integer in [0, 255]"
        self._three_mode = value

    @builtins.property
    def key_pressed(self):
        """Message field 'key_pressed'."""
        return self._key_pressed

    @key_pressed.setter
    def key_pressed(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'key_pressed' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'key_pressed' field must be an unsigned integer in [0, 255]"
        self._key_pressed = value
