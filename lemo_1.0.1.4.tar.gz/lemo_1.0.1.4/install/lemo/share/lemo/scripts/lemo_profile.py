#!/usr/bin/env python3
"""LEMO 硬件 profile 三级配置体系 —— 加载/校验/横幅(库 + 供 launch 与 CLI 共用)。

三级 profile: profiles/gripper/*.yaml、profiles/leader/*.yaml、
/etc/lemo/machine.yaml(板子身份)。两级选择: machine.yaml 常态 +
launch 参数临时覆盖(参数优先)。

防出错设计(全部在本模块落地):
  1. 未知 profile 名 -> ProfileError,列出合法名
  2. schema 校验: 每个 profile 全字段必检(缺字段/类型错/超范围即拒)
  3. 组合白名单: g1z + v2(MIT) 未台架验证,默认拒绝,LEMO_I_KNOW=1 放行
  4. SDK 代际校验: impl=v2 要求 SDK 含 a1z_cpp/include/a1z/gripper_v2.hpp
  5. domain 一致性: ROS_DOMAIN_ID 环境变量与 machine.yaml 不一致 -> WARN

用法(launch 内):
    import lemo_profile
    sel = lemo_profile.load(gripper='g2_mit', leader=None)  # None=按 machine.yaml
    print(sel['banner'])
    arm_params = lemo_profile.arm_bridge_params(sel)   # arm_bridge ROS 参数 dict
    teleop_ovr = lemo_profile.teleop_overrides(sel)    # 合并进 teleop.yaml 的覆盖项
"""

import numbers
import os

import yaml

MACHINE_PATH = '/etc/lemo/machine.yaml'
DEFAULT_GRIPPER = 'g2'
DEFAULT_LEADER = 'evt'

# 夹爪型号与控制实现枚举
GRIPPER_MODELS = ('g2', 'g1z')
GRIPPER_IMPLS = ('v1', 'v2')
GRIPPER_MAPPINGS = ('binary', 'continuous')

# gripper profile schema 取值范围(闭区间,除注明外)
RANGE_TORQUE_NM = (0.0, 2.0)        # 开区间下界: 必须 > 0
RANGE_TRAVEL_RAD = (0.0, 3.5)
RANGE_OVERDRIVE_RAD = (0.0, 0.2)
RANGE_GEOMETRY_RAD = (-3.5, 3.5)
RANGE_V2_TAU_TARGET = (0.0, 5.0)
RANGE_V2_KP = (0.0, 100.0)
RANGE_V2_KD = (0.0, 10.0)
RANGE_V2_V_MAX = (0.0, 50.0)
RANGE_V2_A_MAX = (0.0, 5000.0)
RANGE_V2_J_MAX = (0.0, 1000000.0)
RANGE_TICKS = (0, 4095)
RANGE_DOMAIN_ID = (0, 232)
RANGE_CAMERA_HZ = (1, 60)
CAMERA_ROTATIONS = (0, 90, 180, 270)
RANGE_EXPOSURE_US = (0, 100000)

GRIPPER_FIELDS = ('model', 'impl', 'mapping', 'torque_nm', 'travel_rad',
                  'close_overdrive_rad', 'close_ref_rad', 'geometry', 'urdf',
                  'teleop', 'v2')
GEOMETRY_FIELDS = ('open_rad_left', 'open_rad_right',
                   'close_rad_left', 'close_rad_right')
V2_FIELDS = ('tau_target', 'kp', 'kd', 'v_max', 'a_max')
LEADER_FIELDS = ('description', 'servo_joint_signs',
                 'servo_joint_offsets_deg_left', 'servo_joint_offsets_deg_right',
                 'gripper_ticks')
MACHINE_FIELDS = ('robot_sn', 'ros_domain_id', 'gripper_profile',
                  'leader_profile', 'camera')


class ProfileError(RuntimeError):
    """profile 选择/校验失败;launch 捕获后应直接拒绝启动。"""


def default_profiles_dir():
    """profiles/ 注册表目录: 依次找 环境变量 -> 本模块旁(../scripts -> ../profiles)
    -> share/lemo 布局(scripts/lemo_profile.py -> ../profiles)
    -> /usr/local/share/lemo/profiles(CLI 安装位)。"""
    env = os.environ.get('LEMO_PROFILES_DIR')
    if env:
        return env
    here = os.path.dirname(os.path.realpath(__file__))
    candidates = [
        # 源码树 scripts/lemo_profile.py -> ../profiles;
        # share 布局 share/lemo/scripts/lemo_profile.py -> share/lemo/profiles
        os.path.join(here, '..', 'profiles'),
        '/usr/local/share/lemo/profiles',                # CLI 安装位
    ]
    for cand in candidates:
        if os.path.isdir(os.path.join(cand, 'gripper')):
            return os.path.abspath(cand)
    return os.path.abspath(candidates[0])


def _load_yaml(path):
    try:
        with open(path, 'r') as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as exc:
        raise ProfileError('profile YAML 解析失败 %s: %s' % (path, exc))
    if not isinstance(data, dict):
        raise ProfileError('profile %s 顶层必须是键值映射' % path)
    return data


def _is_num(v):
    return isinstance(v, numbers.Real) and not isinstance(v, bool)


def _check_keys(data, required, where):
    missing = [k for k in required if k not in data]
    if missing:
        raise ProfileError('%s 缺字段: %s(必填: %s)'
                           % (where, ', '.join(missing), ', '.join(required)))


def _check_num(data, key, lo, hi, where, lo_open=True):
    v = data[key]
    if not _is_num(v):
        raise ProfileError('%s.%s 必须是数值,实际: %r' % (where, key, v))
    ok = (v > lo if lo_open else v >= lo) and v <= hi
    if not ok:
        raise ProfileError('%s.%s=%r 超范围 (%s%g, %g]'
                           % (where, key, v, '(' if lo_open else '[', lo, hi))
    return float(v)


def list_profiles(profiles_dir, kind):
    """kind = 'gripper' | 'leader';返回注册表可用名(文件名去 .yaml)。"""
    d = os.path.join(profiles_dir, kind)
    if not os.path.isdir(d):
        return []
    return sorted(os.path.splitext(f)[0] for f in os.listdir(d)
                  if f.endswith('.yaml'))


def _pick_profile_path(profiles_dir, kind, name):
    path = os.path.join(profiles_dir, kind, name + '.yaml')
    if not os.path.isfile(path):
        avail = ', '.join(list_profiles(profiles_dir, kind)) or '(注册表为空)'
        raise ProfileError(
            "未知 %s profile '%s';可用: %s(注册表: %s)"
            % (kind, name, avail, os.path.join(profiles_dir, kind)))
    return path


def validate_gripper(data, where):
    """gripper profile 全字段 schema 校验,返回规范化后的 dict。"""
    _check_keys(data, GRIPPER_FIELDS, where)
    if data['model'] not in GRIPPER_MODELS:
        raise ProfileError('%s.model 必须是 %s,实际: %r'
                           % (where, '/'.join(GRIPPER_MODELS), data['model']))
    if data['impl'] not in GRIPPER_IMPLS:
        raise ProfileError('%s.impl 必须是 %s,实际: %r'
                           % (where, '/'.join(GRIPPER_IMPLS), data['impl']))
    if data['mapping'] not in GRIPPER_MAPPINGS:
        raise ProfileError('%s.mapping 必须是 %s,实际: %r'
                           % (where, '/'.join(GRIPPER_MAPPINGS), data['mapping']))
    out = {
        'model': data['model'], 'impl': data['impl'], 'mapping': data['mapping'],
        'torque_nm': _check_num(data, 'torque_nm', *RANGE_TORQUE_NM, where=where),
        'travel_rad': _check_num(data, 'travel_rad', *RANGE_TRAVEL_RAD, where=where),
        'close_overdrive_rad': _check_num(
            data, 'close_overdrive_rad', *RANGE_OVERDRIVE_RAD, where=where,
            lo_open=False),
        'close_ref_rad': _check_num(
            data, 'close_ref_rad', *RANGE_GEOMETRY_RAD, where=where, lo_open=False),
    }
    geo = data['geometry']
    if not isinstance(geo, dict):
        raise ProfileError('%s.geometry 必须是键值映射' % where)
    _check_keys(geo, GEOMETRY_FIELDS, where + '.geometry')
    vals = [geo[k] for k in GEOMETRY_FIELDS]
    if all(v is None for v in vals):
        out['geometry'] = None        # 由 travel/overdrive 推导
    elif all(_is_num(v) for v in vals):
        for k, v in zip(GEOMETRY_FIELDS, vals):
            if not (RANGE_GEOMETRY_RAD[0] <= v <= RANGE_GEOMETRY_RAD[1]):
                raise ProfileError('%s.geometry.%s=%r 超范围 [%g, %g]'
                                   % (where, k, v, *RANGE_GEOMETRY_RAD))
        out['geometry'] = {k: float(v) for k, v in zip(GEOMETRY_FIELDS, vals)}
    else:
        raise ProfileError(
            '%s.geometry 必须全 null(推导)或全数值(显式),实际: %r' % (where, geo))
    if not (isinstance(data['urdf'], str) and data['urdf']):
        raise ProfileError("%s.urdf 必须是非空字符串('auto' 或显式路径)" % where)
    out['urdf'] = data['urdf']
    teleop = data['teleop']
    if not isinstance(teleop, dict):
        raise ProfileError('%s.teleop 必须是键值映射' % where)
    _check_keys(teleop, ('open_rad', 'close_rad'), where + '.teleop')
    open_rad = _check_num(teleop, 'open_rad', *RANGE_GEOMETRY_RAD,
                          where=where + '.teleop', lo_open=False)
    close_rad = _check_num(teleop, 'close_rad', *RANGE_GEOMETRY_RAD,
                           where=where + '.teleop', lo_open=False)
    if open_rad >= close_rad:
        raise ProfileError('%s.teleop.open_rad 必须小于 close_rad' % where)
    out['teleop'] = {'open_rad': open_rad, 'close_rad': close_rad}
    v2 = data['v2']
    if not isinstance(v2, dict):
        raise ProfileError('%s.v2 必须是键值映射' % where)
    v2 = dict(v2)
    trajectory = v2.pop('trajectory', 's_curve')
    j_max = v2.pop('j_max', 20000.0)
    if trajectory not in ('trapezoid', 's_curve'):
        raise ProfileError('v2.trajectory must be trapezoid or s_curve')
    j_max = _check_num({'j_max': j_max}, 'j_max', *RANGE_V2_J_MAX, where=where + '.v2')
    _check_keys(v2, V2_FIELDS, where + '.v2')
    out['v2'] = {
        'tau_target': _check_num(v2, 'tau_target', *RANGE_V2_TAU_TARGET,
                                 where=where + '.v2'),
        'kp': _check_num(v2, 'kp', *RANGE_V2_KP, where=where + '.v2'),
        'kd': _check_num(v2, 'kd', *RANGE_V2_KD, where=where + '.v2',
                         lo_open=False),
        'v_max': _check_num(v2, 'v_max', *RANGE_V2_V_MAX, where=where + '.v2'),
        'a_max': _check_num(v2, 'a_max', *RANGE_V2_A_MAX, where=where + '.v2'),
    }
    out['v2'].update(trajectory=trajectory, j_max=j_max)
    if trajectory == 's_curve' and out['v2']['v_max'] > 20.0:
        raise ProfileError('S-curve v_max must not exceed 20 rad/s')
    return out


def _check_vec6(data, key, where, sign_only=False, offset_deg=False):
    v = data[key]
    if not (isinstance(v, (list, tuple)) and len(v) == 6
            and all(_is_num(x) for x in v)):
        raise ProfileError('%s.%s 必须是 6 维数值数组' % (where, key))
    out = [float(x) for x in v]
    if sign_only and any(x not in (-1.0, 1.0) for x in out):
        raise ProfileError('%s.%s 逐元素必须为 ±1' % (where, key))
    if offset_deg:
        for x in out:
            if abs(x) > 180.0 or x % 90.0 != 0.0:
                raise ProfileError(
                    '%s.%s 元素须为 90 的倍数且在 ±180 内,实际: %r' % (where, key, x))
    return out


def validate_leader(data, where):
    """leader profile 全字段 schema 校验,返回规范化后的 dict。"""
    _check_keys(data, LEADER_FIELDS, where)
    if not (isinstance(data['description'], str) and data['description']):
        raise ProfileError('%s.description 必须是非空字符串' % where)
    ticks = data['gripper_ticks']
    if not isinstance(ticks, dict):
        raise ProfileError('%s.gripper_ticks 必须是键值映射' % where)
    _check_keys(ticks, ('open', 'closed'), where + '.gripper_ticks')
    for k in ('open', 'closed'):
        v = ticks[k]
        if not (isinstance(v, int) and not isinstance(v, bool)
                and RANGE_TICKS[0] <= v <= RANGE_TICKS[1]):
            raise ProfileError('%s.gripper_ticks.%s 必须是 [%d, %d] 整数,实际: %r'
                               % (where, k, RANGE_TICKS[0], RANGE_TICKS[1], v))
    if ticks['open'] == ticks['closed']:
        raise ProfileError('%s.gripper_ticks.open 与 closed 必须不同' % where)
    return {
        'description': data['description'],
        'servo_joint_signs': _check_vec6(data, 'servo_joint_signs', where,
                                         sign_only=True),
        'servo_joint_offsets_deg_left': _check_vec6(
            data, 'servo_joint_offsets_deg_left', where, offset_deg=True),
        'servo_joint_offsets_deg_right': _check_vec6(
            data, 'servo_joint_offsets_deg_right', where, offset_deg=True),
        'gripper_ticks': {'open': int(ticks['open']),
                          'closed': int(ticks['closed'])},
    }


def validate_machine(data, where):
    """machine.yaml 全字段 schema 校验,返回规范化后的 dict。"""
    _check_keys(data, MACHINE_FIELDS, where)
    if not (isinstance(data['robot_sn'], str) and data['robot_sn']):
        raise ProfileError('%s.robot_sn 必须是非空字符串' % where)
    dom = data['ros_domain_id']
    if not (isinstance(dom, int) and not isinstance(dom, bool)
            and RANGE_DOMAIN_ID[0] <= dom <= RANGE_DOMAIN_ID[1]):
        raise ProfileError('%s.ros_domain_id 必须是 [%d, %d] 整数,实际: %r'
                           % (where, RANGE_DOMAIN_ID[0], RANGE_DOMAIN_ID[1], dom))
    for k in ('gripper_profile', 'leader_profile'):
        if not (isinstance(data[k], str) and data[k]):
            raise ProfileError('%s.%s 必须是非空字符串' % (where, k))
    cam = data['camera']
    if not isinstance(cam, dict):
        raise ProfileError('%s.camera 必须是键值映射' % where)
    _check_keys(cam, ('hz', 'wrist_rotation_deg', 'exposure_us'), where + '.camera')
    if not (isinstance(cam['hz'], int) and not isinstance(cam['hz'], bool)
            and RANGE_CAMERA_HZ[0] <= cam['hz'] <= RANGE_CAMERA_HZ[1]):
        raise ProfileError('%s.camera.hz 必须是 [%d, %d] 整数'
                           % (where, *RANGE_CAMERA_HZ))
    if cam['wrist_rotation_deg'] not in CAMERA_ROTATIONS:
        raise ProfileError('%s.camera.wrist_rotation_deg 必须是 %s'
                           % (where, '/'.join(map(str, CAMERA_ROTATIONS))))
    if not (isinstance(cam['exposure_us'], int)
            and not isinstance(cam['exposure_us'], bool)
            and RANGE_EXPOSURE_US[0] <= cam['exposure_us'] <= RANGE_EXPOSURE_US[1]):
        raise ProfileError('%s.camera.exposure_us 必须是 [%d, %d] 整数'
                           % (where, *RANGE_EXPOSURE_US))
    return {
        'robot_sn': data['robot_sn'],
        'ros_domain_id': int(dom),
        'gripper_profile': data['gripper_profile'],
        'leader_profile': data['leader_profile'],
        'camera': {'hz': int(cam['hz']),
                   'wrist_rotation_deg': int(cam['wrist_rotation_deg']),
                   'exposure_us': int(cam['exposure_us'])},
    }


def _sdk_dirs(profiles_dir, sdk_dir, environ):
    cands = []
    if sdk_dir:
        cands.append(sdk_dir)
    if environ.get('A1Z_SDK_DIR'):
        cands.append(environ['A1Z_SDK_DIR'])
    # 源码树布局: profiles/../sdk/a1z
    cands.append(os.path.join(os.path.dirname(os.path.realpath(profiles_dir)),
                              'sdk', 'a1z'))
    # 标准工作区布局: ~/lemo_linux/sdk/a1z（install 后的 share 布局下
    # profiles/../sdk 不存在,这里兜底——板上 SDK 子模块的固定位置）
    cands.append(os.path.expanduser('~/lemo_linux/sdk/a1z'))
    return cands


def _check_sdk_gen2(profiles_dir, sdk_dir, environ):
    """SDK 代际校验: impl=v2 要求 SDK 含 gripper_v2.hpp。"""
    rel = os.path.join('a1z_cpp', 'include', 'a1z', 'gripper_v2.hpp')
    for d in _sdk_dirs(profiles_dir, sdk_dir, environ):
        if os.path.isfile(os.path.join(d, rel)):
            return os.path.join(d, rel)
    raise ProfileError(
        '选了 v2(MIT) 夹爪实现,但 SDK 不含 %s;查找路径: %s。'
        '请更新 sdk/a1z 子模块或设置 A1Z_SDK_DIR'
        % (rel, ', '.join(_sdk_dirs(profiles_dir, sdk_dir, environ))))


def load(gripper=None, leader=None, machine_path=MACHINE_PATH,
         profiles_dir=None, sdk_dir=None, environ=None):
    """解析生效组合并全部校验。gripper/leader 为 None 时按 machine.yaml。

    返回 dict: gripper/leader(各含 name+profile+path)、machine(或 None)、
    machine_source、warnings、banner。任何校验不过 -> ProfileError。
    """
    environ = os.environ if environ is None else environ
    profiles_dir = os.path.abspath(profiles_dir or default_profiles_dir())
    warnings = []

    machine = None
    machine_source = None
    if os.path.isfile(machine_path):
        machine = validate_machine(_load_yaml(machine_path), machine_path)
        machine_source = machine_path
        env_domain = environ.get('ROS_DOMAIN_ID')
        if env_domain and env_domain.isdigit() \
                and int(env_domain) != machine['ros_domain_id']:
            warnings.append(
                'ROS_DOMAIN_ID 环境变量(%s)与 machine.yaml(%d)不一致,'
                '以 machine.yaml 为准;请统一(禁止两处手改)'
                % (env_domain, machine['ros_domain_id']))
    else:
        warnings.append(
            '未找到 %s,回退默认组合 %s+%s(本机未注册,请部署 machine.yaml)'
            % (machine_path, DEFAULT_GRIPPER, DEFAULT_LEADER))

    gripper_name = gripper or (machine['gripper_profile'] if machine
                               else DEFAULT_GRIPPER)
    if gripper_name == 'g2_mit_scurve':
        gripper_name = 'g2_mit'  # compatibility alias; one canonical MIT profile
    leader_name = leader or (machine['leader_profile'] if machine
                             else DEFAULT_LEADER)

    gpath = _pick_profile_path(profiles_dir, 'gripper', gripper_name)
    lpath = _pick_profile_path(profiles_dir, 'leader', leader_name)
    gprofile = validate_gripper(_load_yaml(gpath), gpath)
    lprofile = validate_leader(_load_yaml(lpath), lpath)

    # 组合白名单: g1z + v2(MIT) 未台架验证,默认拒绝
    if gprofile['model'] == 'g1z' and gprofile['impl'] == 'v2' \
            and environ.get('LEMO_I_KNOW') != '1':
        raise ProfileError(
            "组合 '%s'(g1z + v2 MIT)未台架验证,默认拒绝;确要运行请显式 "
            'LEMO_I_KNOW=1 再启动' % gripper_name)
    # SDK 代际校验
    sdk_v2 = None
    if gprofile['impl'] == 'v2':
        sdk_v2 = _check_sdk_gen2(profiles_dir, sdk_dir, environ)

    sel = {
        'gripper': {'name': gripper_name, 'profile': gprofile, 'path': gpath},
        'leader': {'name': leader_name, 'profile': lprofile, 'path': lpath},
        'machine': machine,
        'machine_source': machine_source,
        'sdk_v2_header': sdk_v2,
        'warnings': warnings,
    }
    sel['banner'] = banner(sel)
    return sel


def banner(sel):
    """三行醒目横幅: gripper / leader / machine 实际生效组合。"""
    g = sel['gripper']['profile']
    l = sel['leader']['profile']
    impl_desc = 'v1 力位混控 %.2fNm' % g['torque_nm'] if g['impl'] == 'v1' \
        else 'v2 MIT tau=%.1fNm kp=%g kd=%g' % (g['v2']['tau_target'],
                                                g['v2']['kp'], g['v2']['kd'])
    signs = ','.join('%g' % x for x in l['servo_joint_signs'])
    if sel['machine']:
        m = sel['machine']
        cam = m['camera']
        machine_line = ('MACHINE = %s | SN=%s domain=%d camera=%dHz/%d°/%dus'
                        % (sel['machine_source'], m['robot_sn'],
                           m['ros_domain_id'], cam['hz'],
                           cam['wrist_rotation_deg'], cam['exposure_us']))
    else:
        machine_line = 'MACHINE = <无 /etc/lemo/machine.yaml,回退默认>'
    sep = '=' * 72
    return '\n'.join([
        sep,
        '[lemo profile] GRIPPER = %s | %s 夹爪 + %s | teleop=%s'
        % (sel['gripper']['name'], g['model'].upper(), impl_desc, g['mapping']),
        '[lemo profile] LEADER  = %s | %s | signs=[%s] ticks=%d/%d'
        % (sel['leader']['name'], l['description'], signs,
           l['gripper_ticks']['open'], l['gripper_ticks']['closed']),
        '[lemo profile] %s' % machine_line,
        sep,
    ])


def arm_bridge_params(sel):
    """gripper profile -> arm_bridge_node ROS 参数 dict(替代 arm_bridge_*.yaml)。"""
    g = sel['gripper']['profile']
    p = {
        'gripper_profile': g['model'],
        'gripper_impl': g['impl'],
        'gripper_max_torque_nm': g['torque_nm'],
        'gripper_travel_rad': g['travel_rad'],
        'gripper_close_overdrive_rad': g['close_overdrive_rad'],
        'gripper_close_ref_rad': g['close_ref_rad'],
    }
    if g['geometry'] is not None:
        p.update({'gripper_' + k: v for k, v in g['geometry'].items()})
    if g['impl'] == 'v2':
        p.update({
            'gripper_v2_tau_target': g['v2']['tau_target'],
            'gripper_v2_kp': g['v2']['kp'],
            'gripper_v2_kd': g['v2']['kd'],
            'gripper_v2_v_max': g['v2']['v_max'],
            'gripper_v2_a_max': g['v2']['a_max'],
            'gripper_v2_trajectory': g['v2']['trajectory'],
            'gripper_v2_j_max': g['v2']['j_max'],
        })
    if g['urdf'] != 'auto':
        p['urdf_path'] = g['urdf']
    return p


def teleop_overrides(sel):
    """leader+gripper profile -> teleop.yaml 同名项覆盖(深合并用)。

    调用方读基准 teleop.yaml,用返回 dict 深合并后写临时文件,
    经 config_path 传给 teleop_bridge_node。
    """
    l = sel['leader']['profile']
    g = sel['gripper']['profile']
    return {
        'servo_joint_signs': [int(x) for x in l['servo_joint_signs']],
        'servo_joint_offsets_deg_left': l['servo_joint_offsets_deg_left'],
        'servo_joint_offsets_deg_right': l['servo_joint_offsets_deg_right'],
        'gripper_ticks': dict(l['gripper_ticks']),
        'gripper_binary': {'enabled': g['mapping'] == 'binary'},
        'follower_gripper': {
            'open_rad': g['teleop']['open_rad'],
            'close_rad': g['teleop']['close_rad'],
            'max_torque_nm': g['torque_nm'],
        },
    }
