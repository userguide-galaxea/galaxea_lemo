#!/usr/bin/env bash
set -eo pipefail
# ROS Humble setup uses variables that may be unset; do not enable nounset
# while sourcing it.
set +u
source /opt/ros/humble/setup.bash
set -u
DATA_COLLECTION_INSTALL="${DATA_COLLECTION_INSTALL:-}"
if [ -z "$DATA_COLLECTION_INSTALL" ] || [ ! -f "$DATA_COLLECTION_INSTALL/local_setup.bash" ]; then
  echo "data_collection install overlay not found" >&2
  echo "set DATA_COLLECTION_INSTALL to the directory containing local_setup.bash" >&2
  exit 1
fi
set +u
# setup.bash in this prebuilt overlay records the underlay used by its
# producer and currently points at ROS Jazzy. Humble is sourced above, so load
# only this overlay and do not replay that stale underlay chain.
source "$DATA_COLLECTION_INSTALL/local_setup.bash"
set -u
sleep "${DATA_COLLECTION_START_DELAY:-8}"
exec nice -n 10 ros2 launch data_collection data_collection_launch.py upload_task_num:="${UPLOAD_TASK_NUM:-2}"
