#!/usr/bin/env bash
source /opt/ros/humble/setup.bash
COLCON_CURRENT_PREFIX="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$COLCON_CURRENT_PREFIX/local_setup.bash"
unset COLCON_CURRENT_PREFIX
