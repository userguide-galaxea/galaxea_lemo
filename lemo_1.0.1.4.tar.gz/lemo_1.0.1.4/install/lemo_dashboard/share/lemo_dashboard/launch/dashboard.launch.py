from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('port', default_value='8000',
                              description='HTTP 服务端口'),
        Node(
            package='lemo_dashboard',
            executable='lemo-dashboard',
            name='lemo_dashboard',
            output='both',
            arguments=['--port', LaunchConfiguration('port')],
        ),
    ])
